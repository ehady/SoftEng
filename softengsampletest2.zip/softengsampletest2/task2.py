import requests
from bs4 import BeautifulSoup

url = "https://www.worldometers.info/coronavirus/country/poland/"

response = requests.get(url)

tree = BeautifulSoup(response.content,'html.parser')

total_cases = tree.find_all('div', {'class': 'maincounter-number'})

for cases in total_cases:
    if cases.find_previous("h1").text.strip() == 'Deaths:':
        result = cases.span.text.strip()
        print(result)


# print(total_cases)