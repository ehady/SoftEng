import pandas as pd

df = pd.read_csv("C:\\Users\\lenovo\\Downloads\\covid_19_clean.csv")

df_countries = df['Country/Region'].value_counts()

# print(df_countries)

df_italy_death = df[df['Country/Region'] == 'Italy']

print(df_italy_death['Deaths'].sum())
print(df_italy_death['Deaths'].max())